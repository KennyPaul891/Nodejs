export class search {
  search: string;
}

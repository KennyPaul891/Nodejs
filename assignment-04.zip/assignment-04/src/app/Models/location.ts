export class location {
  street: any;
  city: string;
  state: string;
  country: string;
  postcode: number;
  coordinates: any;
  timezone: any;
}

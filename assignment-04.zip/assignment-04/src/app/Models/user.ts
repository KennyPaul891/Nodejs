import { location } from './location';

export class User {
  gender: string;
  name: any;
  location: location;
  email: any;
  login: any;
  dob: any;
  registered: any;
  phone: string;
  cell: string;
  id: any;
  picture: any;
  nat: any;
}
